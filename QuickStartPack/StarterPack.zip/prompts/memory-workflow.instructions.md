---
description: Memory best practices
applyTo: "**"
---

# Memory MCP – Task‑Driven Workflow (with Valid JSON Calls & Chaining Rationale)

## 1. Get the Task + Its Neighborhood

```json
{ "name": "open_nodes", "arguments": { "names": ["${TASK_ID}"] } }
```

```json
{ "name": "search_nodes", "arguments": { "query": "${TASK_ID}" } }
```

> **Why chain `open_nodes` ➜ `search_nodes`?** > `open_nodes` is exact and fast; `search_nodes` pulls matched entities **and their relations**, ensuring you don’t miss dependencies/research already linked. If either is incomplete, fall back: ([GitHub][1])

```json
{ "name": "read_graph", "arguments": {} }
```

> **Why `read_graph` last?** It’s the nuclear option—full graph dump—so only use it when targeted calls didn’t surface everything. ([GitHub][1])

---

## 2. Record Research/Decisions Immediately After Discovery

```json
{
  "name": "create_entities",
  "arguments": {
    "entities": [
      {
        "name": "research_${TASK_ID}_${TIMESTAMP}",
        "entityType": "decision",
        "observations": [
          "Research findings: …",
          "Technologies validated: …",
          "Builds on: …"
        ]
      }
    ]
  }
}
```

```json
{
  "name": "create_relations",
  "arguments": {
    "relations": [
      {
        "from": "${TASK_ID}",
        "to": "research_${TASK_ID}_${TIMESTAMP}",
        "relationType": "has_research"
      },
      {
        "from": "research_${TASK_ID}_${TIMESTAMP}",
        "to": "${RELATED_DECISION}",
        "relationType": "builds_on"
      }
    ]
  }
}
```

> **Why chain `create_entities` ➜ `create_relations`?**
> New knowledge is useless if it’s unlinked. Always attach each new entity back to the task and any prior decisions so future queries surface it automatically. ([GitHub][1])

---

## 3. Plan & Track Progress Incrementally

```json
{
  "name": "add_observations",
  "arguments": {
    "observations": [
      {
        "entityName": "${TASK_ID}",
        "contents": [
          "Progress: Step ${N} complete",
          "Implementation status: ${status}"
        ]
      }
    ]
  }
}
```

> **Why add observations early and often?**
> The task node becomes the single source of truth for status. Using `contents` (correct key) lets you append atomic facts without rewriting the entity. ([GitHub][1])

---

## 4. Capture New Patterns/Decisions During Implementation

````json
{
  "name": "create_entities",
  "arguments": {
    "entities": [
      {
        "name": "pattern_${NAME}",
        "entityType": "pattern",
        "observations": [
          "Description: …",
          "Code example: ```python\n...\n```",
          "Use case: …"
        ]
      }
    ]
  }
}
````

```json
{
  "name": "create_relations",
  "arguments": {
    "relations": [
      {
        "from": "pattern_${NAME}",
        "to": "${TASK_ID}",
        "relationType": "used_by"
      }
    ]
  }
}
```

> **Why chain every “pattern” or “decision” to the task?**
> It guarantees reverse lookups (task ➜ pattern, pattern ➜ tasks) and keeps reuse discoverable. ([GitHub][1])

---

## 5. Close Out Cleanly

```json
{
  "name": "add_observations",
  "arguments": {
    "observations": [
      {
        "entityName": "${TASK_ID}",
        "contents": [
          "Status: DONE",
          "Completed: ${DATE}",
          "All acceptance criteria met",
          "Dead code: None detected"
        ]
      }
    ]
  }
}
```

```json
{
  "name": "create_entities",
  "arguments": {
    "entities": [
      {
        "name": "impl_summary_${TASK_ID}_${TIMESTAMP}",
        "entityType": "decision",
        "observations": [
          "What was implemented",
          "Key decisions made",
          "Impact & next steps"
        ]
      }
    ]
  }
}
```

```json
{
  "name": "create_relations",
  "arguments": {
    "relations": [
      {
        "from": "${TASK_ID}",
        "to": "impl_summary_${TASK_ID}_${TIMESTAMP}",
        "relationType": "completed_with"
      }
    ]
  }
}
```

> **Why final summary + relations?**
> A closure entity gives you a compact postmortem. Linking it ensures future audits can jump straight to “how/why we did this.” ([GitHub][1])

---

## 6. (Optional) Cleanup When Needed

```json
{
  "name": "delete_relations",
  "arguments": {
    "relations": [{ "from": "A", "to": "B", "relationType": "uses" }]
  }
}
```

```json
{
  "name": "delete_entities",
  "arguments": {
    "entityNames": ["obsolete_entity"]
  }
}
```

```json
{
  "name": "delete_observations",
  "arguments": {
    "deletions": [
      {
        "entityName": "John_Smith",
        "observations": ["Prefers morning meetings"]
      }
    ]
  }
}
```

> **Why chain deletes after refactors?**
> Dead links & stale facts pollute searches. Prune immediately to keep the graph high-signal. ([GitHub][1])

---

### Chaining Rule of Thumb

**Fetch → Validate → Write → Link → Log → Summarize → (Optionally) Prune**
Every write (`create_entities`, `add_observations`) should be immediately followed by `create_relations` to anchor it in context. Every major step should append an observation to the task node for traceability. ([GitHub][1])

[1]: https://raw.githubusercontent.com/modelcontextprotocol/servers/refs/heads/main/src/memory/README.md "raw.githubusercontent.com"
